package com.akkodis.codingchallenge.taco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TacoApplicationTests {

	@Test
	void contextLoads() {
	}

}
